//
//  SecondVC.swift
//  Newsfeed
//
//  Created by kireeti on 15/11/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import UIKit
import BetterSegmentedControl
class SecondVC: UIViewController {

    
    @IBOutlet var segmentControl: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
       
         
       
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
//extension UISegmentedControl {
//    func setSegmentStyle() {
//        setBackgroundImage(imageWithColor(color: backgroundColor!), for: .normal, barMetrics: .default)
//        setBackgroundImage(imageWithColor(color: tintColor!), for: .selected, barMetrics: .default)
//        setDividerImage(imageWithColor(color: UIColor.clear), forLeftSegmentState: .normal, rightSegmentState: .normal, barMetrics: .default)
//
//        //NSForegroundColorAttributeName
//
//        let segAttributes: NSDictionary = [
//            : UIColor.gray,
//            NSFontAttributeName: UIFont(name: "System-System", size: 14)!
//        ]
//
//        setTitleTextAttributes(segAttributes as [NSObject : AnyObject], for: UIControlState.selected)
//    }
//
//    // create a 1x1 image with this color
//    private func imageWithColor(color: UIColor) -> UIImage {
//        let rect = CGRect(x: 0.0, y: 0.0, width:  1.0, height: 1.0)
//        UIGraphicsBeginImageContext(rect.size)
//        let context = UIGraphicsGetCurrentContext()
//        context!.setFillColor(color.cgColor);
//        context!.fill(rect);
//        let image = UIGraphicsGetImageFromCurrentImageContext();
//        UIGraphicsEndImageContext();
//        return image!
//    }
//}
