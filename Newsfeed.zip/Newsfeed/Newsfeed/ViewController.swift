//
//  ViewController.swift
//  Newsfeed
//
//  Created by kireeti on 14/11/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import UIKit
import Kingfisher

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var attachmeArr = [Data1]()
    var a = NSMutableArray()
   

  
   
    @IBOutlet var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        parseJson()
     
    }

    func parseJson(){
        let urlStr = "http://13.228.97.103/socialcommerce-laravel/public/api/feeds?magento_id=203"
        let url = URL.init(string: urlStr)
        let urlReq = URLRequest.init(url: url!)
        URLSession.shared.dataTask(with: urlReq) { (data, response, error) in
             guard let data = data else { return }
            do{
            let json = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments) as! NSDictionary
            //print(json)
                let dataObj = json["data"] as! [[String: Any]]
             
               // print(dataObj)
                for i in dataObj{
                    self.attachmeArr.append(Data1.init(dict: i))
                    //self.a.add(Data1.init(dict: i).attachment1.first?.thumbnail!)
                  
                 }
//
                for i in 0..<Int(self.attachmeArr.count){
                   
                    let urlData = self.attachmeArr[i].attachment1.first?.thumbnail
                    if urlData == nil{
                        
                    }else{
                    print("UrlData------->",urlData)
                    self.a.add(urlData!)
                    }
//
             }
               
                 print("urlData---->/n", self.a)
               
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
               
                
            }catch{
                print(error.localizedDescription)
            }
            
        }.resume()
        
            
        
        }
        
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return self.a.count
    }
    
   

   
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        
        if self.a[indexPath.row] is NSNull{
            
        }else{
            cell.img.translatesAutoresizingMaskIntoConstraints = false
            cell.img.kf.setImage(with: URL.init(string: self.a[indexPath.row] as! String))
        }
        
        return cell
    }
    
}
    
   
    




