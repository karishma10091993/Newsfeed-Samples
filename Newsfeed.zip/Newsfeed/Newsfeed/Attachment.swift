//
//  Attachment.swift
//  Newsfeed
//
//  Created by kireeti on 14/11/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import Foundation
enum AttachmentType: String {
    case video, image
}
class Data1 {
    
    var k_likes : Int?
    var k_comments : Int?
    var k_shares: Int?
   var attachment1 = [Attachment]()
    var attachement = [[String:Any]]()
    init(dict: [String:Any]) {
        self.attachement = (dict ["attachment"] as? [[String :Any]])!
        self.k_likes =   dict["k_views"] as? Int
        self.k_comments = dict["k_comments"] as? Int
        self.k_shares = dict["k_shares"] as? Int
        
        for  item in attachement{
            self.attachment1.append(Attachment.init(dict: item))
        }
    }
}

class Attachment {
    var attachmentType: AttachmentType?
var type : String?
var  thumbnail : String?
var url : String?
    init(dict:[String: Any]) {
        self.attachmentType = AttachmentType(rawValue: dict["type"] as! String)
        self.type = dict["type"] as? String
        self.thumbnail = dict["thumbnail"] as? String
        self.url = dict["url"] as? String
        
    }
}
