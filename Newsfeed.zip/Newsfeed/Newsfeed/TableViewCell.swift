//
//  TableViewCell.swift
//  Newsfeed
//
//  Created by kireeti on 15/11/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet var img: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    
}
