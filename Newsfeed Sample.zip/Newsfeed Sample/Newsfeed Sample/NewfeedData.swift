//
//  NewfeedData.swift
//  Newsfeed Sample
//
//  Created by kireeti on 27/10/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import Foundation
class NewsFeed {
    
    var json: Any?
    var meta = Meta()
    var data = [Data]()
    var paging = Paging()
    var links = Links()
    var timeStamp: String?
    var timeZone: String?
    
   
    
}

class Meta {
    var success: Bool
    var code: String
    var message: String
    
    init(dict :[String: Any]) {
        self.success = dict["success"] as! Bool
        self.code = dict["code"] as! String
        self.message = dict["message"] as! String
    }
}

class Data {
       
    var message : String
    var attachment = [Attachment]()
    var view : Int
    var comments : Int
    var likes : Int
    var shares : Int
    var type : String
    var created_at : String
    var user_name : String
    init(dict: [String : Any]) {
        self.message = dict["message"] as! String
        self.view = dict["k_views"] as! Int
        self.comments = dict["k_comments"] as! Int
        self.likes = dict["k_likes"] as! Int
        self.shares = dict["k_shares"] as! Int
        self.created_at = dict["created_at"] as! String
        let attachments = dict["attachment"] as! [[String: Any]]
        
        for item in attachments {
            let attachmentData = Attachment.init(dict: item)
            self.attachment.append(attachmentData)
        }
        
    }
    
}

class Attachment {
    var type : String
    var thumbnail: String
    var url : String
    var img : String
    
    init(dict: [String: Any]) {
        self.type = dict["image"] as! String
        self.thumbnail = dict["thumbnail"] as! String
        self.url = dict["url"] as! String
        
        if  self.type == "image" && self.thumbnail != nil {
            self.img = self.thumbnail
        }
    }
    
}
    

